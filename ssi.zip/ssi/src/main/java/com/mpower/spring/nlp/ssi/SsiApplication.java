package com.mpower.spring.nlp.ssi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SsiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SsiApplication.class, args);
	}
}
