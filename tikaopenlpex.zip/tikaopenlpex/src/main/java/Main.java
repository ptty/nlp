import org.apache.tika.exception.TikaException;
import org.xml.sax.SAXException;

import java.io.IOException;

public class Main {
     public static void main(String[] args) throws IOException, TikaException, SAXException {

         Recognition toi = new Recognition();
         toi.write("", "extrdata.txt", true);
         String cnt = toi.contentEx();
         toi.sentenceD(cnt);
         toi.tokenization(cnt);

         String names = toi.namefind(toi.Tokens);
         toi.write(names, "extrdata.txt", false);
    }
}
